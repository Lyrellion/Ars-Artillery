
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arsartillery.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.arsartillery.block.display.WaterstoneDisplayItem;
import net.mcreator.arsartillery.block.display.ManipulationstoneDisplayItem;
import net.mcreator.arsartillery.block.display.FirestoneDisplayItem;
import net.mcreator.arsartillery.block.display.EarthstoneDisplayItem;
import net.mcreator.arsartillery.block.display.ConjurationstoneDisplayItem;
import net.mcreator.arsartillery.block.display.AirstoneDisplayItem;
import net.mcreator.arsartillery.block.display.AbjurationstoneDisplayItem;
import net.mcreator.arsartillery.ArsArtilleryMod;

public class ArsArtilleryModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ArsArtilleryMod.MODID);
	public static final RegistryObject<Item> FIRE_TURRET_1_SPAWN_EGG = REGISTRY.register("fire_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.FIRE_TURRET_1, -6710887, -65536, new Item.Properties()));
	public static final RegistryObject<Item> FIRE_TURRET_2_SPAWN_EGG = REGISTRY.register("fire_turret_2_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.FIRE_TURRET_2, -6710887, -65536, new Item.Properties()));
	public static final RegistryObject<Item> FIRE_TURRET_3_SPAWN_EGG = REGISTRY.register("fire_turret_3_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.FIRE_TURRET_3, -6710887, -65536, new Item.Properties()));
	public static final RegistryObject<Item> FIRESTONE = REGISTRY.register(ArsArtilleryModBlocks.FIRESTONE.getId().getPath(), () -> new FirestoneDisplayItem(ArsArtilleryModBlocks.FIRESTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> AIRSTONE = REGISTRY.register(ArsArtilleryModBlocks.AIRSTONE.getId().getPath(), () -> new AirstoneDisplayItem(ArsArtilleryModBlocks.AIRSTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> WATERSTONE = REGISTRY.register(ArsArtilleryModBlocks.WATERSTONE.getId().getPath(), () -> new WaterstoneDisplayItem(ArsArtilleryModBlocks.WATERSTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> EARTHSTONE = REGISTRY.register(ArsArtilleryModBlocks.EARTHSTONE.getId().getPath(), () -> new EarthstoneDisplayItem(ArsArtilleryModBlocks.EARTHSTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> ABJURATIONSTONE = REGISTRY.register(ArsArtilleryModBlocks.ABJURATIONSTONE.getId().getPath(), () -> new AbjurationstoneDisplayItem(ArsArtilleryModBlocks.ABJURATIONSTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> CONJURATIONSTONE = REGISTRY.register(ArsArtilleryModBlocks.CONJURATIONSTONE.getId().getPath(), () -> new ConjurationstoneDisplayItem(ArsArtilleryModBlocks.CONJURATIONSTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> MANIPULATIONSTONE = REGISTRY.register(ArsArtilleryModBlocks.MANIPULATIONSTONE.getId().getPath(),
			() -> new ManipulationstoneDisplayItem(ArsArtilleryModBlocks.MANIPULATIONSTONE.get(), new Item.Properties()));
	public static final RegistryObject<Item> WATER_TURRET_1_SPAWN_EGG = REGISTRY.register("water_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.WATER_TURRET_1, -6710887, -16763905, new Item.Properties()));
	public static final RegistryObject<Item> AIR_TURRET_1_SPAWN_EGG = REGISTRY.register("air_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.AIR_TURRET_1, -6710887, -1, new Item.Properties()));
	public static final RegistryObject<Item> EARTH_TURRET_1_SPAWN_EGG = REGISTRY.register("earth_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.EARTH_TURRET_1, -6710887, -10027264, new Item.Properties()));
	public static final RegistryObject<Item> ABJURATION_TURRET_1_SPAWN_EGG = REGISTRY.register("abjuration_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.ABJURATION_TURRET_1, -6710887, -39169, new Item.Properties()));
	public static final RegistryObject<Item> CONJURATION_TURRET_1_SPAWN_EGG = REGISTRY.register("conjuration_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.CONJURATION_TURRET_1, -6710887, -16711732, new Item.Properties()));
	public static final RegistryObject<Item> MANIPULATION_TURRET_1_SPAWN_EGG = REGISTRY.register("manipulation_turret_1_spawn_egg", () -> new ForgeSpawnEggItem(ArsArtilleryModEntities.MANIPULATION_TURRET_1, -6710887, -13261, new Item.Properties()));
	// Start of user code block custom items
	// End of user code block custom items
}
