
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.arsartillery.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.arsartillery.entity.WaterTurret1Entity;
import net.mcreator.arsartillery.entity.ManipulationTurret1Entity;
import net.mcreator.arsartillery.entity.FireTurret3Entity;
import net.mcreator.arsartillery.entity.FireTurret2Entity;
import net.mcreator.arsartillery.entity.FireTurret1Entity;
import net.mcreator.arsartillery.entity.FireShotEntity;
import net.mcreator.arsartillery.entity.EarthTurret1Entity;
import net.mcreator.arsartillery.entity.ConjurationTurret1Entity;
import net.mcreator.arsartillery.entity.AirTurret1Entity;
import net.mcreator.arsartillery.entity.AbjurationTurret1Entity;
import net.mcreator.arsartillery.ArsArtilleryMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ArsArtilleryModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ArsArtilleryMod.MODID);
	public static final RegistryObject<EntityType<FireTurret1Entity>> FIRE_TURRET_1 = register("fire_turret_1",
			EntityType.Builder.<FireTurret1Entity>of(FireTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FireTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FireTurret2Entity>> FIRE_TURRET_2 = register("fire_turret_2",
			EntityType.Builder.<FireTurret2Entity>of(FireTurret2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FireTurret2Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FireTurret3Entity>> FIRE_TURRET_3 = register("fire_turret_3",
			EntityType.Builder.<FireTurret3Entity>of(FireTurret3Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FireTurret3Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<WaterTurret1Entity>> WATER_TURRET_1 = register("water_turret_1",
			EntityType.Builder.<WaterTurret1Entity>of(WaterTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WaterTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<AirTurret1Entity>> AIR_TURRET_1 = register("air_turret_1",
			EntityType.Builder.<AirTurret1Entity>of(AirTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AirTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EarthTurret1Entity>> EARTH_TURRET_1 = register("earth_turret_1",
			EntityType.Builder.<EarthTurret1Entity>of(EarthTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EarthTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<AbjurationTurret1Entity>> ABJURATION_TURRET_1 = register("abjuration_turret_1",
			EntityType.Builder.<AbjurationTurret1Entity>of(AbjurationTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AbjurationTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ConjurationTurret1Entity>> CONJURATION_TURRET_1 = register("conjuration_turret_1",
			EntityType.Builder.<ConjurationTurret1Entity>of(ConjurationTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ConjurationTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ManipulationTurret1Entity>> MANIPULATION_TURRET_1 = register("manipulation_turret_1",
			EntityType.Builder.<ManipulationTurret1Entity>of(ManipulationTurret1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ManipulationTurret1Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<FireShotEntity>> FIRE_SHOT = register("fire_shot",
			EntityType.Builder.<FireShotEntity>of(FireShotEntity::new, MobCategory.MISC).setCustomClientFactory(FireShotEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			FireTurret1Entity.init();
			FireTurret2Entity.init();
			FireTurret3Entity.init();
			WaterTurret1Entity.init();
			AirTurret1Entity.init();
			EarthTurret1Entity.init();
			AbjurationTurret1Entity.init();
			ConjurationTurret1Entity.init();
			ManipulationTurret1Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FIRE_TURRET_1.get(), FireTurret1Entity.createAttributes().build());
		event.put(FIRE_TURRET_2.get(), FireTurret2Entity.createAttributes().build());
		event.put(FIRE_TURRET_3.get(), FireTurret3Entity.createAttributes().build());
		event.put(WATER_TURRET_1.get(), WaterTurret1Entity.createAttributes().build());
		event.put(AIR_TURRET_1.get(), AirTurret1Entity.createAttributes().build());
		event.put(EARTH_TURRET_1.get(), EarthTurret1Entity.createAttributes().build());
		event.put(ABJURATION_TURRET_1.get(), AbjurationTurret1Entity.createAttributes().build());
		event.put(CONJURATION_TURRET_1.get(), ConjurationTurret1Entity.createAttributes().build());
		event.put(MANIPULATION_TURRET_1.get(), ManipulationTurret1Entity.createAttributes().build());
	}
}
